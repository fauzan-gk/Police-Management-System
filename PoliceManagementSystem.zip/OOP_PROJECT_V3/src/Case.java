import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Case implements CaseManagement {
    private int caseID;
    private String caseDescription;
    private String status;
    private ArrayList<Suspect> suspects;
    private ArrayList<PoliceOfficer> officers;

    public Case(int caseID, String caseDescription) {
        this.caseID = caseID;
        this.caseDescription = caseDescription;
        this.status = "Open";
        this.suspects = new ArrayList<>();
        this.officers = new ArrayList<>();
    }

    public void addOfficer(PoliceOfficer officer) {
        officers.add(officer);
    }

    public ArrayList<PoliceOfficer> getOfficers() {
        return officers;
    }

    public int getCaseID() {
        return caseID;
    }

    public String getCaseDescription() {
        return caseDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void addSuspect(Suspect suspect) {
        suspects.add(suspect);
    }

    public ArrayList<Suspect> getSuspects() {
        return suspects;
    }

    public void addSuspects(ArrayList<Suspect> suspects) {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter the number of suspects to add: ");
            int numberOfSuspects = input.nextInt();
            input.nextLine();

            for (int i = 0; i < numberOfSuspects; i++) {
                boolean validSuspect = false;

                while (!validSuspect) {
                    System.out.println("Choose an existing suspect or create a new one:");
                    System.out.println("1. Choose Existing Suspect");
                    System.out.println("2. Create New Suspect");
                    int choice = input.nextInt();
                    input.nextLine();

                    if (choice == 1) {
                        System.out.println("Available Suspects:");
                        for (Suspect suspect : suspects) {
                            System.out.println("Suspect ID: " + suspect.getSuspectID() + ", Name: " + suspect.getName());
                        }
                        System.out.print("Enter Suspect ID to add: ");
                        int suspectID = input.nextInt();
                        input.nextLine();

                        for (Suspect suspect : suspects) {
                            if (suspect.getSuspectID() == suspectID) {
                                addSuspect(suspect);
                                validSuspect = true;
                                break;
                            }
                        }

                        if (!validSuspect) {
                            System.out.println("Suspect not found. Please try again.");
                        }
                    } else if (choice == 2) {
                        System.out.print("Enter Name: ");
                        String name = input.nextLine();
                        System.out.print("Enter Address: ");
                        String address = input.nextLine();
                        System.out.print("Enter Phone Number: ");
                        String phoneNumber = input.nextLine();
                        System.out.print("Enter Suspect ID: ");
                        int suspectID = input.nextInt();
                        input.nextLine();

                        boolean idExists = false;
                        for (Suspect existingSuspect : suspects) {
                            if (existingSuspect.getSuspectID() == suspectID) {
                                idExists = true;
                                break;
                            }
                        }

                        if (idExists) {
                            System.out.println("Suspect ID already exists. Please enter a different Suspect ID: ");
                            suspectID = input.nextInt();
                            input.nextLine();
                        }

                        System.out.print("Enter Status: ");
                        String status = input.nextLine();
                        System.out.print("Enter Crime: ");
                        String crime = input.nextLine();

                        Suspect newSuspect = new Suspect(name, address, phoneNumber, suspectID, status, crime);
                        suspects.add(newSuspect);
                        addSuspect(newSuspect );
                        validSuspect = true;
                    }
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please try again.");
            input.nextLine();
        } catch (NumberFormatException e) {
            System.out.println("Invalid suspect ID format. Please enter valid numbers.");
        }
    }

    public void displayDetails() {
        System.out.println("--- Case Details ---");
        System.out.println("Case ID: " + caseID);
        System.out.println("Description: " + caseDescription);
        System.out.println("Status: " + status);
        System.out.println("Suspects: ");
        for (Suspect suspect : suspects) {
            suspect.displayDetails();
            System.out.println("---------------------------");
        }
        System.out.println("Officers Handling the Case: ");
        for (PoliceOfficer officer : officers) {
            officer.displayDetails();
            System.out.println("---------------------------");
        }
    }
}
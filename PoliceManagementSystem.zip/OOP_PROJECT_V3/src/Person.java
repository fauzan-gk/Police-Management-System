public abstract class Person {
    protected String name;
    protected String address;
    protected String phoneNumber;

    public Person() {
        name = "null";
        address = "null";
        phoneNumber = "null";
    }

    public Person(String name, String address, String phoneNumber) {
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    public abstract void displayDetails();

    protected abstract void setName(String next);
}
import java.util.Scanner;

public class Civilian extends Person {
    public Civilian() {
    }

    public Civilian(String name, String address, String phoneNumber) {
        super(name, address, phoneNumber);
    }

    public void displayDetails() {
        System.out.println("--- Civilian Details ---");
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Phone Number: " + phoneNumber);
    }

    @Override
    protected void setName(String next) {
        this.name = name;
    }

    public void setter() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter civilian name: ");
        name = input.next();
        System.out.println("Enter civilian address: ");
        address = input.next();
        System.out.println("Enter civilian phone number: ");
        phoneNumber = input.next();
    }
}
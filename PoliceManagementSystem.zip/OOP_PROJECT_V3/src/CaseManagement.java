import java.util.ArrayList;

public interface CaseManagement {
    void addOfficer(PoliceOfficer officer);
    void addSuspect(Suspect suspect);
    void addSuspects(ArrayList<Suspect> suspects);
    void displayDetails();
}
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class PoliceManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Admin admin = new Admin();
        Department department = new Department(1, "Abbottabad");
        ArrayList<PoliceOfficer> officers = new ArrayList<>();
        ArrayList<Case> cases = new ArrayList<>();
        ArrayList<Suspect> suspects = new ArrayList<>();

        while (true) {
            System.out.println("Welcome to the Police Management System");
            System.out.println("1. Manage Police Officers");
            System.out.println("2. Manage Cases");
            System.out.println("3. Manage Suspects");
            System.out.println("4. Generate Report");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            try {
                int mainChoice = scanner.nextInt();
                switch (mainChoice) {
                    case 1:
                        managePoliceOfficers(scanner, admin, officers, department);
                        break;
                    case 2:
                        manageCases(scanner, cases, suspects, officers);
                        break;
                    case 3:
                        manageSuspects(scanner, suspects);
                        break;
                    case 4:
                        manageReports(scanner, officers, cases, suspects);
                        break;
                    case 5:
                        System.out.println("Exiting the system. Goodbye!");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    private static void manageReports(Scanner scanner, ArrayList<PoliceOfficer> officers, ArrayList<Case> cases, ArrayList<Suspect> suspects) {
        while (true) {
            System.out.println("Report Menu");
            System.out.println("1. Total Number of Police Officers");
            System.out.println("2. Total Number of Cases");
            System.out.println("3. Total Number of Suspects");
            System.out.println("4. List of Active Cases");
            System.out.println("5. List of Suspects Involved in Cases");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");

            try {
                int reportChoice = scanner.nextInt();
                File myFile = new File("data.txt");
                FileWriter fw = new FileWriter(myFile, true);
                fw.write("Report generated on: " + java.time.LocalDateTime.now() + "\n");

                switch (reportChoice) {
                    case 1:
                        int totalOfficers = officers.size();
                        System.out.println("Total Number of Police Officers: " + totalOfficers);
                        fw.write("Total Number of Police Officers: " + totalOfficers + "\n");
                        break;
                    case 2:
                        int totalCases = cases.size();
                        System.out.println("Total Number of Cases: " + totalCases);
                        fw.write("Total Number of Cases: " + totalCases + "\n");
                        break;
                    case 3:
                        int totalSuspects = suspects.size();
                        System.out.println("Total Number of Suspects: " + totalSuspects);
                        fw.write("Total Number of Suspects: " + totalSuspects + "\n");
                        break;
                    case 4:
                        System.out.println("List of Active Cases:");
                        fw.write("List of Active Cases:\n");
                        for (Case policeCase : cases) {
                            if (policeCase.getStatus().equalsIgnoreCase("Open")) {
                                policeCase.displayDetails();
                                fw.write("Case ID: " + policeCase.getCaseID() + ", Description: " + policeCase.getCaseDescription() + "\n");
                            }
                        }
                        break;
                    case 5:
                        System.out.println("List of Suspects Involved in Cases:");
                        fw.write("List of Suspects Involved in Cases:\n");
                        for (Case policeCase : cases) {
                            System.out.println("Case ID: " + policeCase.getCaseID());
                            fw.write("Case ID: " + policeCase.getCaseID() + "\n");
                            for (Suspect suspect : policeCase.getSuspects()) {
                                suspect.displayDetails();
                                fw.write("Suspect ID: " + suspect.getSuspectID() + ", Name: " + suspect.getName() + "\n");
                            }
                        }
                        break;
                    case 6:
                        fw.close();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
                fw.close();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            } catch (IOException e) {
                System.out.println("Error handling file: " + e.getMessage());
            }
        }
    }

    private static void manageSuspects(Scanner scanner, ArrayList<Suspect> suspects) {
        while (true) {
            System.out.println("Manage Suspects");
            System.out.println("1. Add Suspect");
            System.out.println("2. Update Suspect");
            System.out.println("3. Delete Suspect");
            System.out.println("4. Search Suspect");
            System.out.println("5. Display All Suspects");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            try {
                int choice = scanner.nextInt();
                scanner.nextLine();
                switch (choice) {
                    case 1:
                        Suspect newSuspect = Suspect.addSuspect(scanner, suspects);
                        if (newSuspect != null) {
                            suspects.add(newSuspect);
                            System.out.println("Suspect added successfully!");
                        }
                        break;
                    case 2:
                        System.out.print("Enter Suspect ID to update: ");
                        int suspectIDToUpdate = scanner.nextInt();
                        Suspect suspectToUpdate = findSuspectByID(suspectIDToUpdate, suspects);
                        if (suspectToUpdate != null) {
                            System.out.print("Enter new Suspect ID: ");
                            int newSuspectID = scanner.nextInt();
                            scanner.nextLine();
                            if (newSuspectID != suspectToUpdate.getSuspectID() && Suspect.isDuplicateID(suspects, newSuspectID)) {
                                System.out.println("Suspect ID already exists. Please enter a unique ID.");
                            } else {
                                if (newSuspectID != suspectToUpdate.getSuspectID()) {
                                    suspectToUpdate.setSuspectID(newSuspectID);
                                }
                                suspectToUpdate.updateSuspect(scanner, suspects);
                                System.out.println("Suspect updated successfully!");
                            }
                        } else {
                            System.out.println("Suspect not found.");
                        }
                        break;
                    case 3:
                        System.out.print("Enter Suspect ID to delete: ");
                        int suspectIDToDelete = scanner.nextInt();
                        Suspect suspectToDelete = findSuspectByID(suspectIDToDelete, suspects);
                        if (suspectToDelete != null) {
                            suspects.remove(suspectToDelete);
                            System.out.println("Suspect deleted successfully!");
                        } else {
                            System.out.println("Suspect not found.");
                        }
                        break;
                    case 4:
                        System.out.print("Enter Suspect ID to search: ");
                        int suspectIDToSearch = scanner.nextInt();
                        Suspect suspectToSearch = findSuspectByID(suspectIDToSearch, suspects);
                        if (suspectToSearch != null) {
                            suspectToSearch.displayDetails();
                        } else {
                            System.out.println("Suspect not found.");
                        }
                        break;
                    case 5:
                        if (suspects.isEmpty()) {
                            System.out.println("No suspects found!");
                        } else {
                            System.out.println("List of Suspects:");
                            for (Suspect suspect : suspects) {
                                suspect.displayDetails();
                            }
                        }
                        break;
                    case 6:
                        return;
                    default:
                        System.out.println("Invalid option");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    private static Suspect findSuspectByID(int suspectID, ArrayList<Suspect> suspects) {
        for (Suspect suspect : suspects) {
            if (suspect.getSuspectID() == suspectID) {
                return suspect;
            }
        }
        return null;
    }

    private static void managePoliceOfficers(Scanner scanner, Admin admin, ArrayList<PoliceOfficer> officers, Department department) {
        while (true) {
            System.out.println("Manage Police Officers");
            System.out.println("1. Add Police Officer");
            System.out.println("2. Delete Police Officer");
            System.out.println("3. Update Police Officer");
            System.out.println("4. Search Police Officer");
            System.out.println("5. Display All Officers");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            try {
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        PoliceOfficer newOfficer = admin.addOfficer(department);
                        if (newOfficer != null) {
                            officers.add(newOfficer);
                        }
                        break;
                    case 2:
                        System.out.print("Enter Officer ID to remove: ");
                        int officerIDToRemove = scanner.nextInt();
                        PoliceOfficer officerToDelete = null;
                        for (PoliceOfficer officer : officers) {
                            if (officer.getOfficerID() == officerIDToRemove) {
                                officerToDelete = officer;
                                break;
                            }
                        }
                        if (officerToDelete != null) {
                            officers.remove(officerToDelete);
                            admin.deleteOfficer(officerToDelete);
                        } else {
                            System.out.println("Officer not found!");
                        }
                        break;

                    case 3:
                        System.out.print("Enter Officer ID to update: ");
                        try {
                            int officerIDToUpdate = scanner.nextInt();
                            scanner.nextLine();

                            PoliceOfficer officerToUpdate = null;
                            for (PoliceOfficer officer : officers) {
                                if (officer.getOfficerID() == officerIDToUpdate) {
                                    officerToUpdate = officer;
                                    break;
                                }
                            }

                            if (officerToUpdate != null) {
                                admin.updateOfficer(officerToUpdate);
                            } else {
                                System.out.println("Officer not found.");
                            }
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input. Please enter a valid Officer ID.");
                            scanner.nextLine();
                        }
                        break;

                    case 4:
                        System.out.print("Enter Officer ID to search: ");
                        int officerIDToSearch = scanner.nextInt();
                        PoliceOfficer officerToSearch = null;
                        for (PoliceOfficer officer : officers) {
                            if (officer.getOfficerID() == officerIDToSearch) {
                                officerToSearch = officer;
                                break;
                            }
                        }
                        if (officerToSearch != null) {
                            officerToSearch.displayDetails();
                        } else {
                            System.out.println("Officer not found.");
                        }
                        break;
                    case 5:
                        if (officers.isEmpty()) {
                            System.out.println("No officers found!");
                        } else {
                            System.out.println("List of Police Officers:");
                            for (PoliceOfficer officer : officers) {
                                officer.displayDetails();
                                System.out.println("---------------------------");
                            }
                        }
                        break;
                    case 6:
                        return;
                    default:
                        System.out.println("Invalid option");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    private static void manageCases(Scanner scanner, ArrayList<Case> cases, ArrayList<Suspect> suspects, ArrayList<PoliceOfficer> officers) {
        while (true) {
            System.out.println("Manage Cases");
            System.out.println("1. Add Case");
            System.out.println("2. Update Case Status");
            System.out.println("3. Delete Case");
            System.out.println("4. Display All Cases");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            try {
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        addCase(scanner, cases, suspects, officers);
                        break;
                    case 2:
                        System.out.print("Enter Case ID to update: ");
                        int caseIDToUpdate = scanner.nextInt();
                        Case caseToUpdate = null;
                        for (Case policeCase : cases) {
                            if (policeCase.getCaseID() == caseIDToUpdate) {
                                caseToUpdate = policeCase;
                                break;
                            }
                        }
                        if (caseToUpdate != null) {
                            System.out.print("Enter new status: ");
                            String newStatus = scanner.next();
                            caseToUpdate.setStatus(newStatus);
                            System.out.println("Case updated successfully!");
                        } else {
                            System.out.println("Case not found.");
                        }
                        break;
                    case 3:
                        System.out.print("Enter Case ID to delete: ");
                        int caseIDToDelete = scanner.nextInt();
                        Case caseToDelete = null;
                        for (Case policeCase : cases) {
                            if (policeCase.getCaseID() == caseIDToDelete) {
                                caseToDelete = policeCase;
                                break;
                            }
                        }
                        if (caseToDelete != null) {
                            cases.remove(caseToDelete);
                            System.out.println("Case deleted successfully!");
                        } else {
                            System.out.println("Case not found.");
                        }
                        break;
                    case 4:
                        if (cases.isEmpty()) {
                            System.out.println("No cases found!");
                        } else {
                            System.out.println("List of Cases:");
                            for (Case policeCase : cases) {
                                policeCase.displayDetails();
                                System.out.println("---------------------------");
                            }
                        }
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid option");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    private static PoliceOfficer findOfficerById(ArrayList<PoliceOfficer> officers, int officerID) {
        for (PoliceOfficer officer : officers) {
            if (officer.getOfficerID() == officerID) {
                return officer;
            }
        }
        return null;
    }

    private static void addCase(Scanner scanner, ArrayList<Case> cases, ArrayList<Suspect> suspects, ArrayList<PoliceOfficer> officers) {

        try {
            int caseID;
            boolean isUnique;

            do {
                System.out.print("Enter Case ID: ");
                caseID = scanner.nextInt();
                scanner.nextLine();
                isUnique = true;

                for (Case existingCase : cases) {
                    if (existingCase.getCaseID() == caseID) {
                        System.out.println("Case ID already exists. Please enter a different Case ID: ");
                        isUnique = false;
                        break;
                    }
                }
            } while (!isUnique);

            System.out.print("Enter Case Description: ");
            String description = scanner.nextLine();

            Case newCase = new Case(caseID, description);

            newCase.addSuspects(suspects);

            System.out.println("Select Officer(s) handling this case (enter officer IDs, separated by commas): ");
            String[] officerIDs = scanner.nextLine().split(",");
            for (String id : officerIDs) {
                int officerID = Integer.parseInt(id.trim());
                PoliceOfficer officer = findOfficerById(officers, officerID);
                if (officer != null) {
                    newCase.addOfficer(officer);
                } else {
                    System.out.println("Officer with ID " + officerID + " not found.");
                }
            }

            cases.add(newCase);
            System.out.println("Case added successfully!");
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please try again.");
            scanner.nextLine();
        } catch (NumberFormatException e) {
            System.out.println("Invalid officer ID format. Please enter valid numbers.");
        }
    }
}
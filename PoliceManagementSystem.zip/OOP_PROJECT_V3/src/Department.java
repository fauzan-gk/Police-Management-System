import java.util.ArrayList;

public class Department {
    protected int departmentID;
    protected String departmentName;
    private ArrayList<PoliceOfficer> officers;

    public Department(int departmentID, String departmentName) {
        this.departmentID = departmentID;
        this.departmentName = departmentName;
        this.officers = new ArrayList<>();
    }

    public int getDepartmentID() {
        return departmentID;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public ArrayList<PoliceOfficer> getOfficers() {
        return officers;
    }

    public void displayDepartmentDetails() {
        System.out.println("--- Department Details ---");
        System.out.println("Department Name: " + departmentName);
        System.out.println("Department ID: " + departmentID);
        for (PoliceOfficer officer : officers) {
            officer.displayDetails();
            System.out.println("-------");
        }
    }
}
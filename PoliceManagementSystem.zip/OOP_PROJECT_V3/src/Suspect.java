import java.util.ArrayList;
import java.util.Scanner;

public class Suspect {
    private String name;
    private String address;
    private String phoneNumber;
    private int suspectID;
    private String status;
    private String crime;

    public Suspect(String name, String address, String phoneNumber, int suspectID, String status, String crime) {
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.suspectID = suspectID;
        this.status = status;
        this.crime = crime;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public int getSuspectID() { return suspectID; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getCrime() { return crime; }
    public void setCrime(String crime) { this.crime = crime; }

    public void displayDetails() {
        System.out.println("Suspect ID: " + suspectID);
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Status: " + status);
        System.out.println("Crime: " + crime);
    }

    public static Suspect addSuspect(Scanner scanner, ArrayList<Suspect> suspects) {
        System.out.print("Enter Suspect Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Address: ");
        String address = scanner.nextLine();
        System.out.print("Enter Phone Number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter Suspect ID: ");
        int suspectID = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Status: ");
        String status = scanner.nextLine();
        System.out.print("Enter Crime: ");
        String crime = scanner.nextLine();

        if (isDuplicateID(suspects, suspectID)) {
            System.out.println("Suspect ID already exists. Please enter a unique ID.");
            return null;
        }

        return new Suspect(name, address, phoneNumber, suspectID, status, crime);
    }

    // Method to update suspect details
    public void updateSuspect(Scanner scanner, ArrayList<Suspect> suspects) {
        System.out.print("Update Name: ");
        this.setName(scanner.nextLine());
        System.out.print("Update Address: ");
        this.setAddress(scanner.nextLine());
        System.out.print("Update Phone Number: ");
        this.setPhoneNumber(scanner.nextLine());
        System.out.print("Update Status: ");
        this.setStatus(scanner.nextLine());
        System.out.print("Update Crime: ");
        this.setCrime(scanner.next());
    }

    // Method to check for duplicate IDs
    public static boolean isDuplicateID(ArrayList<Suspect> suspects, int suspectID) {
        for (Suspect suspect : suspects) {
            if (suspect.getSuspectID() == suspectID) {
                return true;
            }
        }
        return false;
    }

    public void setSuspectID(int newSuspectID) {
        this.suspectID = suspectID;
    }
}
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Admin extends PoliceOfficer implements OfficerManagement {
    private ArrayList<PoliceOfficer> officers;

    public Admin() {
        officers = new ArrayList<>();
    }

    public Admin(String name, String address, String phoneNumber, int officerID, String rank, Department department) {
        super(name, address, phoneNumber, officerID, rank, department);
    }

    public PoliceOfficer addOfficer(Department department) {
        Scanner input = new Scanner(System.in);
        try {
            System.out.println("Enter Police Officer Name: ");
            name = input.nextLine();
            System.out.println("Enter Address: ");
            address = input.nextLine();
            System.out.println("Enter Phone Number: ");
            phoneNumber = input.next();

            int officerID;
            boolean isUnique;

            do {
                System.out.println("Enter Officer ID: ");
                officerID = input.nextInt();
                isUnique = true;

                for (PoliceOfficer existingOfficer : officers) {
                    if (existingOfficer.getOfficerID() == officerID) {
                        System.out.println("Officer ID already exists. Please enter a different Officer ID: ");
                        isUnique = false;
                        break;
                    }
                }
            } while (!isUnique);

            System.out.println("Enter Rank: ");
            rank = input.next();

            PoliceOfficer officer = new PoliceOfficer(name, address, phoneNumber, officerID, rank, department);
            officers.add(officer);
            return officer;
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please try again.");
            input.nextLine();
            return null;
        }
    }

    public void updateOfficer(PoliceOfficer officer) {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Update Officer Name: ");
            officer.setName(input.nextLine());

            System.out.print("Update Address: ");
            officer.setAddress(input.nextLine());

            System.out.print("Update Phone Number: ");
            officer.setPhoneNumber(input.nextLine());

            int newOfficerID;
            boolean idExists;

            do {
                System.out.print("Update Officer ID: ");
                newOfficerID = input.nextInt();
                input.nextLine();

                idExists = false;
                for (PoliceOfficer existingOfficer : officers) {
                    if (existingOfficer.getOfficerID() == newOfficerID && existingOfficer != officer) {
                        idExists = true;
                        System.out.println("Officer ID already exists. Please enter a different Officer ID.");
                        break;
                    }
                }
            } while (idExists);

            officer.setOfficerID(newOfficerID);

            System.out.print("Update Rank: ");
            officer.setRank(input.nextLine());

            System.out.println("Officer details updated successfully!");
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please try again.");
            input.nextLine();
        }
    }

    public void deleteOfficer(PoliceOfficer officer) {
        officers.remove(officer);
        System.out.println("Officer " + officer.getName() + " removed successfully!");
    }

    public ArrayList<PoliceOfficer> getOfficers() {
        return officers;
    }

    public void addDepartment() {
    }
}
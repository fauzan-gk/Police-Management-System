public class PoliceOfficer extends Person {
    protected int officerID;
    protected String rank;
    private Department department;

    public PoliceOfficer() {
        officerID = -1;
        rank = "null";
    }

    public PoliceOfficer(String name, String address, String phoneNumber, int officerID, String rank, Department department) {
        super(name, address, phoneNumber);
        this.officerID = officerID;
        this.rank = rank;
        this.department = department;
    }

    public int getOfficerID() {
        return officerID;
    }

    public void setOfficerID(int officerID) {
        this.officerID = officerID;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Officer ID: " + officerID);
        System.out.println("Rank: " + rank);
        System.out.println("Department: " + (department != null ? department.getDepartmentName() : "None"));
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        PoliceOfficer that = (PoliceOfficer) obj;
        return officerID == that.officerID;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(officerID);
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }
}
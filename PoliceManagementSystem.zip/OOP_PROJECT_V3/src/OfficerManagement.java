public interface OfficerManagement {
    PoliceOfficer addOfficer(Department department);
    void deleteOfficer(PoliceOfficer officer);
    void updateOfficer(PoliceOfficer officer);
}